<?php
$dbPath = 'access_control.db';
$db = new SQLite3($dbPath);
$mensaje = "";

// 1. PROCESAR ELIMINACIÓN DE USUARIO
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $uidToDelete = trim($_POST['uid']);
    if (!empty($uidToDelete)) {
        $stmtDelete = $db->prepare("DELETE FROM users WHERE uid = :uid");
        $stmtDelete->bindValue(':uid', $uidToDelete, SQLITE3_TEXT);
        if ($stmtDelete->execute()) {
            $mensaje = "<div style='color: #4ade80; margin-bottom: 15px; text-align: center; font-weight: bold;'>¡Usuario con UID {$uidToDelete} eliminado con éxito!</div>";
        } else {
            $mensaje = "<div style='color: #f87171; margin-bottom: 15px; text-align: center;'>Error al intentar eliminar el usuario.</div>";
        }
    }
}

// 2. PROCESAR REGISTRO DE USUARIO
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register') {
    $uid = trim($_POST['uid']);
    $nombre = trim($_POST['nombre']);
    $rol = $_POST['rol'];

    if (!empty($uid) && !empty($nombre)) {
        $stmt = $db->prepare("INSERT INTO users (uid, nombre, activo, rol) VALUES (:uid, :nombre, 1, :rol)");
        $stmt->bindValue(':uid', $uid, SQLITE3_TEXT);
        $stmt->bindValue(':nombre', $nombre, SQLITE3_TEXT);
        $stmt->bindValue(':rol', $rol, SQLITE3_TEXT);
        
        if ($stmt->execute()) {
            $mensaje = "<div style='color: #4ade80; margin-bottom: 15px; text-align: center; font-weight: bold;'>¡Usuario registrado con éxito!</div>";
        } else {
            $mensaje = "<div style='color: #f87171; margin-bottom: 15px; text-align: center;'>Error: El UID ya existe o hay un problema.</div>";
        }
    } else {
        $mensaje = "<div style='color: #fbbf24; margin-bottom: 15px; text-align: center;'>Por favor llena todos los campos.</div>";
    }
}

// 3. OBTENER LISTA DE USUARIOS REGISTRADOS
$userResults = $db->query("SELECT * FROM users ORDER BY rowid DESC");
$usuarios = [];
if ($userResults) {
    while ($userRow = $userResults->fetchArray(SQLITE3_ASSOC)) {
        $usuarios[] = $userRow;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Administración - Control de Acceso</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #121212; color: #e0e0e0; display: flex; flex-direction: column; align-items: center; min-height: 100vh; margin: 0; padding: 30px 20px; box-sizing: border-box; }
        .container { display: flex; flex-direction: row; gap: 25px; width: 100%; max-width: 950px; flex-wrap: wrap; justify-content: center; }
        .card { background: #1e1e1e; padding: 25px 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); flex: 1; min-width: 380px; }
        h2 { text-align: center; color: #fff; margin-bottom: 20px; font-size: 22px; }
        
        /* Estilo para la ventanita de captura de NFC */
        .scanner-box { background: #252525; border: 2px dashed #4f46e5; padding: 15px; border-radius: 8px; text-align: center; margin-bottom: 20px; }
        .scanner-box p { margin: 0 0 8px 0; font-size: 13px; color: #a5b4fc; }
        .uid-display { font-family: monospace; font-size: 18px; color: #4ade80; background: #121212; padding: 8px; border-radius: 4px; letter-spacing: 1px; }

        label { display: block; margin-bottom: 5px; font-size: 14px; }
        input, select { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #444; border-radius: 6px; background: #2c2c2c; color: #fff; box-sizing: border-box; }
        .btn-submit { width: 100%; padding: 11px; background: #4f46e5; border: none; border-radius: 6px; color: white; font-weight: bold; cursor: pointer; font-size: 15px; }
        .btn-submit:hover { background: #4338ca; }
        .btn-delete { background: #dc2626; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: bold; }
        .btn-delete:hover { background: #b91c1c; }
        
        /* Tabla de Usuarios */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }
        th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #333; }
        th { background-color: #252525; color: #a5b4fc; font-weight: 600; }
        tr:hover { background-color: #2a2a2a; }
        .badge { padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .badge-admin { background: #4f46e5; color: #fff; }
        .badge-normal { background: #374151; color: #d1d5db; }

        .back { text-align: center; margin-top: 25px; width: 100%; }
        .back a { color: #818cf8; text-decoration: none; font-size: 14px; }
        .back a:hover { text-decoration: underline; }
    </style>
    <script>
        // Escuchar tarjetas pasadas en tiempo real
        setInterval(function() {
            fetch('get_ultimo_uid.php')
                .then(response => response.json())
                .then(data => {
                    if (data.uid && data.uid !== "") {
                        document.getElementById('uidCapturado').innerText = data.uid;
                        document.getElementById('uidInput').value = data.uid;
                    }
                })
                .catch(error => console.log('Buscando lector...'));
        }, 1000);
    </script>
</head>
<body>

    <h1 style="color: #fff; margin-bottom: 25px; font-size: 26px;">Panel de Administración - Control de Acceso</h1>
    
    <?= $mensaje ?>

    <div class="container">
        <!-- FORMULARIO DE REGISTRO -->
        <div class="card">
            <h2>Registrar Nuevo Usuario</h2>
            
            <div class="scanner-box">
               
                <div class="uid-display" id="uidCapturado">Esperando tarjeta...</div>
            </div>

            <form method="POST">
                <input type="hidden" name="action" value="register">
                
                <label>UID Detectado:</label>
                <input type="text" id="uidInput" name="uid" placeholder="Se llenará automáticamente..." required readonly>
                
                <label>Nombre del Propietario:</label>
                <input type="text" name="nombre" placeholder="Ej. Carlos Mendoza" required>
                
                <label>Rol de Usuario:</label>
                <select name="rol">
                    <option value="normal">Normal</option>
                    <option value="admin">Administrador</option>
                </select>
                
                <button type="submit" class="btn-submit">Registrar Usuario</button>
            </form>
        </div>

        <!-- TABLA DE USUARIOS REGISTRADOS -->
        <div class="card">
            <h2>Usuarios Registrados (<?= count($usuarios) ?>)</h2>
            
            <?php if (count($usuarios) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>UID</th>
                            <th>Nombre</th>
                            <th>Rol</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $u): ?>
                            <tr>
                                <td style="font-family: monospace; color: #4ade80;"><?= htmlspecialchars($u['uid']) ?></td>
                                <td><?= htmlspecialchars($u['nombre']) ?></td>
                                <td>
                                    <span class="badge <?= ($u['rol'] === 'admin') ? 'badge-admin' : 'badge-normal' ?>">
                                        <?= strtoupper(htmlspecialchars($u['rol'] ?? 'normal')) ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" style="margin: 0;" onsubmit="return confirm('¿Seguro que deseas eliminar a <?= htmlspecialchars($u['nombre']) ?> (UID: <?= htmlspecialchars($u['uid']) ?>)?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="uid" value="<?= htmlspecialchars($u['uid']) ?>">
                                        <button type="submit" class="btn-delete">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; color: #888; padding: 20px;">No hay usuarios registrados en la base de datos.</div>
            <?php endif; ?>
        </div>
    </div>

    <div class="back">
        <a href="index.php">← Volver al Monitor en Vivo</a>
    </div>

</body>
</html>
