<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
date_default_timezone_set('America/Mexico_City');

$dbPath = '/opt/lampp/htdocs/api/access_control.db';

if (!file_exists($dbPath)) {
    echo json_encode(["uid" => ""]);
    exit();
}

$db = new SQLite3($dbPath);

// Obtener la última tarjeta registrada en la base de datos
$result = $db->query("SELECT uid, created_at FROM access_log ORDER BY id DESC LIMIT 1");
$row = $result ? $result->fetchArray(SQLITE3_ASSOC) : false;

$uid = "";

if ($row && !empty($row['uid']) && !empty($row['created_at'])) {
    $scanTime = strtotime($row['created_at']);
    $currentTime = time();
    $diffSeconds = $currentTime - $scanTime;

    // Solo devolver el UID si la tarjeta fue escaneada en tiempo real (hace 10 segundos o menos)
    if ($scanTime !== false && abs($diffSeconds) <= 10) {
        $uid = $row['uid'];
    }
}

$db->close();

echo json_encode(["uid" => $uid]);
?>
