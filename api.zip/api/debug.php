<?php
$db = new SQLite3('/opt/lampp/htdocs/api/access_control.db');
$result = $db->query("SELECT * FROM users");
echo "--- USUARIOS EN LA BD DE XAMPP ---\n";
while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    echo "ID: {$row['id']} | UID: '{$row['uid']}' | Nombre: {$row['nombre']} | Activo: {$row['activo']}\n";
}
$db->close();
?>
