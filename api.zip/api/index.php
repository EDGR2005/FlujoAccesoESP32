<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Monitor de Accesos en Vivo</title>
    <meta http-equiv="refresh" content="3">
    <style>
        body { font-family: Arial, sans-serif; background: #121212; color: #e0e0e0; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .card { background: #1e1e1e; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); width: 600px; text-align: center; }
        h1 { color: #fff; font-size: 24px; margin-bottom: 20px; }
        
        /* Contenedor de logs con estilo de terminal */
        .log-box {padding: 15px; border-radius: 6px; text-align: left; max-height: 250px; overflow-y: auto; font-family: monospace; font-size: 13px; }
        
        /* Clases de color para los textos */
        .log-success { color: #4ade80; } /* Verde para concedido */
        .log-denied { color: #f87171; font-weight: bold; } /* Rojo brillante para denegado */

        .links { margin-top: 20px; }
        .links a { color: #818cf8; text-decoration: none; font-size: 14px; margin: 0 10px; }
        .links a:hover { text-decoration: underline; }
    </style>
    <script>
        // Verificación en tiempo real para saltar al panel de admin si el último log es de admin
        setInterval(function() {
            fetch('verificar_ultimo_admin.php')
                .then(response => response.json())
                .then(data => {
                    if (data.es_admin) {
                        window.location.href = 'admin.php';
                    }
                })
                .catch(error => console.log('Esperando eventos...'));
        }, 2000);
    </script>
</head>
<body>
    <div class="card">
        <h1> Monitor de Accesos en Vivo</h1>
        <p>Esperando tarjetas... (La pantalla se actualiza sola)</p>
        
        <div class="log-box">
            <?php
                $logFile = 'registro.txt';
                if (file_exists($logFile)) {
                    $lines = file($logFile);
                    $recent = array_slice($lines, -10); // Mostrar los últimos 10 registros
                    
                    foreach ($recent as $line) {
                        $escapedLine = htmlspecialchars($line);
                        // Si la línea contiene "DENEGADO", la envolvemos en un span rojo, de lo contrario verde
                        if (strpos($line, 'DENEGADO') !== false) {
                            echo "<div class='log-denied'>{$escapedLine}</div>";
                        } else {
                            echo "<div class='log-success'>{$escapedLine}</div>";
                        }
                    }
                } else {
                    echo "<div style='color: #888;'>No hay registros aún.</div>";
                }
            ?>
        </div>

       
    </div>
</body>
</html>
