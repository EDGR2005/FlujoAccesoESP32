<?php
header('Content-Type: application/json');
$dbPath = 'access_control.db';
$handledFile = 'last_handled_id.txt';

if (!file_exists($dbPath)) {
    echo json_encode(["es_admin" => false]);
    exit();
}

$db = new SQLite3($dbPath);

// 1. Buscar el último registro de un administrador en los logs
$query = "SELECT l.id, u.rol FROM access_log l JOIN users u ON l.uid = u.uid WHERE u.rol = 'admin' AND u.activo = 1 ORDER BY l.id DESC LIMIT 1";
$result = $db->query($query);
$row = $result ? $result->fetchArray(SQLITE3_ASSOC) : false;

$esAdmin = false;

if ($row) {
    $ultimoIdLog = (int)$row['id'];
    
    // 2. Leer el ID del último evento que ya provocó redirección
    $lastHandledId = 0;
    if (file_exists($handledFile)) {
        $lastHandledId = (int)file_get_contents($handledFile);
    }
    
    // 3. Si es un acceso nuevo que no ha sido atendido, activamos la redirección una sola vez
    if ($ultimoIdLog > $lastHandledId) {
        $esAdmin = true;
        // Marcar este ID como ya procesado para evitar bucles futuros
        file_put_contents($handledFile, $ultimoIdLog);
    }
}

$db->close();
echo json_encode(["es_admin" => $esAdmin]);
?>
