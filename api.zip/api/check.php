<<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
date_default_timezone_set('America/Mexico_City');

$dbPath = '/opt/lampp/htdocs/api/access_control.db'; 
$date = date('Y-m-d H:i:s');
$logFile = 'registro.txt';

if (!file_exists($dbPath)) {
    echo json_encode(["granted" => false, "message" => "Error: Base de datos no encontrada"]);
    exit();
}

$db = new SQLite3($dbPath);
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (isset($data['uid'])) {
    $uid = $db->escapeString($data['uid']);
    
    $stmt = $db->prepare("SELECT * FROM users WHERE uid = :uid AND activo = 1");
    $stmt->bindValue(':uid', $uid, SQLITE3_TEXT);
    $result = $stmt->execute();
    $row = $result->fetchArray(SQLITE3_ASSOC);
    
    $granted = 0;
    
    if ($row) {
        $nombre = $row['nombre'];
        $rol = isset($row['rol']) ? $row['rol'] : 'normal';
        
        if ($rol === 'admin') {
            $status = "ACCESO ADMIN CONCEDIDO ($nombre)";
            $response = [
                "granted" => true, 
                "is_admin" => true, 
                "message" => "Bienvenido Admin " . $nombre,
                "redirect_url" => "http://192.168.1.98/api/admin.php"
            ];
        } else {
            $status = "ACCESO CONCEDIDO ($nombre)";
            $response = [
                "granted" => true, 
                "is_admin" => false, 
                "message" => "Bienvenido " . $nombre
            ];
        }
        $granted = 1;
    } else {
        $status = "ACCESO DENEGADO";
        $response = [
            "granted" => false, 
            "is_admin" => false, 
            "message" => "Acceso Denegado"
        ];
    }
    
    // Registrar en archivo de texto
    $logEntry = "[$date] UID: $uid -> $status\n";
    file_put_contents($logFile, $logEntry, FILE_APPEND);
    
    // Registrar en la base de datos (access_log)
    $logStmt = $db->prepare("INSERT INTO access_log (uid, granted, created_at) VALUES (:uid, :granted, :created_at)");
    $logStmt->bindValue(':uid', $uid, SQLITE3_TEXT);
    $logStmt->bindValue(':granted', $granted, SQLITE3_INTEGER);
    $logStmt->bindValue(':created_at', $date, SQLITE3_TEXT);
    $logStmt->execute();
    
    echo json_encode($response);
} else {
    echo json_encode(["granted" => false, "message" => "Error: No se recibio UID"]);
}

$db->close();
?>
